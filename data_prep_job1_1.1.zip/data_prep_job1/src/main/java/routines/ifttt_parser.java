package routines;
import java.io.*;


/**
 * parse the date and url from IFTTT email: parsing info
 * 
 *
 * {talendTypes} String
 * 
 * {Category} User Defined
 * 
 */
public class ifttt_parser {

    public static String[] parser_email(String filePath) {
    	String file_name = filePath;//((String)globalMap.get("tPOP_1_CURRENT_FILEPATH")) ;
    	String[] output = new String[2];
		try{
			String fileInputPath=file_name;
			InputStream is = new FileInputStream(fileInputPath);
			BufferedReader buf = new BufferedReader(new InputStreamReader(is));
			String line = buf.readLine();
			StringBuilder sb = new StringBuilder();
			while(line != null){
			   sb.append(line).append("\n");
			   line = buf.readLine();
			}
			String content=sb.toString();
			if((content.indexOf("Content-Transfer-Encoding: quoted-printable\n\n\n\n")!=-1 || content.indexOf("Content-Transfer-Encoding: 7bit\n\n\n\n")!=-1 )&& content.indexOf("http://ift.tt/")!=-1){
				int timeTagStartIndex=-1;
				int timeTagEndIndex=-1;
				String timeTagSnippet="n/a";
				if(content.indexOf("Content-Transfer-Encoding: quoted-printable\n\n\n\n")!=-1){
					timeTagStartIndex=content.indexOf("Content-Transfer-Encoding: quoted-printable\n\n\n\n")+"Content-Transfer-Encoding: quoted-printable\n\n\n\n".length();
					String tmp=content.substring(timeTagStartIndex);
					if(tmp.indexOf("PM")!=-1){
						timeTagEndIndex=tmp.indexOf("PM")+"PM".length();
					}else if(tmp.indexOf("AM")!=-1){
						timeTagEndIndex=tmp.indexOf("AM")+"AM".length();
					}
					if(timeTagEndIndex!=-1){
						timeTagSnippet=tmp.substring(0,timeTagEndIndex).trim();
					}
				}
				else if(content.indexOf("Content-Transfer-Encoding: 7bit\n\n\n\n")!=-1){
					timeTagStartIndex=content.indexOf("Content-Transfer-Encoding: 7bit\n\n\n\n")+"Content-Transfer-Encoding: 7bit\n\n\n\n".length();
					String tmp=content.substring(timeTagStartIndex);
					if(tmp.indexOf("PM")!=-1){
						timeTagEndIndex=tmp.indexOf("PM")+"PM".length();
					}else if(tmp.indexOf("AM")!=-1){
						timeTagEndIndex=tmp.indexOf("AM")+"AM".length();
					}
					if(timeTagEndIndex!=-1){
						timeTagSnippet=tmp.substring(0,timeTagEndIndex).trim();
					}
				}
				int iftLinkStartIndex=-1;
				int iftLinkEndIndex=-1;
				String iftLinkSnippet="n/a";
				iftLinkStartIndex=content.indexOf("http://ift.tt/");
				String tmp=content.substring(iftLinkStartIndex);
				iftLinkEndIndex=tmp.indexOf("</td>");
				if(iftLinkEndIndex!=-1){
					iftLinkSnippet=tmp.substring(0,iftLinkEndIndex).trim();
				}
				buf.close();
				
				output[0]=timeTagSnippet;
				output[1]=iftLinkSnippet;
				//System.out.println("IFT link: "+iftLinkSnippet);
			}
		}catch(Exception error){
			error.printStackTrace();
		}
		return output;
    }
    
    public static String parser_iftSimpleurlResponse(String ifturl) throws Exception{
    	String output=null;
		try{
			if(ifturl.indexOf("URL='")!=-1){
				int urlStartIndex=-1;
				int urlEndIndex=-1;
				urlStartIndex=ifturl.indexOf("URL=")+"<URL=".length();
				String tmp=ifturl.substring(urlStartIndex);
				if(tmp.indexOf("'\">")!=-1){
					urlEndIndex=tmp.indexOf("'\">");
					output=tmp.substring(0,urlEndIndex);
				}
			}
		}catch(Exception error){
			error.printStackTrace();
		}
		if(output!=null){
			output=output.trim();
		}
		return output;
    }
}
